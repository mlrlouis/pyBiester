"""
Package pymonster
"""