"""
Tests für bene_strategie.py
"""
import pytest
from pyBiester.bene_strategie import BeastBrain


@pytest.fixture
def brain():
    """Erzeugt eine neue Instanz von BeastBrain für jeden Test."""
    return BeastBrain()


# --- Hilfsmethoden ---

def test_idx_to_pos(brain):
    """Prüft, ob die Umwandlung Index → Position korrekt funktioniert."""
    assert brain.idx_to_pos(5, 3) == (1, 2)
    assert brain.idx_to_pos(0, 3) == (0, 0)
    assert brain.idx_to_pos(8, 3) == (2, 2)


def test_pos_to_move_limits(brain):
    """Prüft, ob Bewegungsgrenzen (n) korrekt berücksichtigt werden."""
    dx, dy = brain.pos_to_move(10, 10, 0, 0)
    assert abs(dx) <= brain.n
    assert abs(dy) <= brain.n


def test_dist_calculation(brain):
    """Prüft die Distanzberechnung anhand eines bekannten Beispiels."""
    env_size = 3
    i = 8  # unten rechts
    dist = brain.dist(i, 0, 0, env_size)
    assert round(dist, 2) == 2.83  # sqrt(8)


def test_find_relatives(brain):
    """Überprüft, ob Verwandte korrekt im Environment erkannt werden."""
    env = "...#..#.."
    size = 3
    relatives = brain.find_relatives(env, size)
    assert (1, 0) in relatives or (1, 2) in relatives
    assert len(relatives) == 2


def test_check_relatives_true(brain):
    """Gibt True zurück, wenn auf dem Zielfeld ein Verwandter steht."""
    env = "........."
    size = 3
    env = env[:5] + '#' + env[6:]
    result = brain.check_relatives(env, 1, 0, 1, 1, size)
    assert result is True


def test_check_relatives_false(brain):
    """Gibt False zurück, wenn auf dem Zielfeld kein Verwandter steht."""
    env = "........."
    size = 3
    result = brain.check_relatives(env, 1, 0, 0, 2, size)
    assert result is False


# --- Entscheidungslogik (decide) ---

def test_decide_move_to_food(brain):
    """Wenn Futter in Reichweite ist, soll das Biest sich dorthin bewegen."""
    env = "..*......"  # Futter vorne rechts
    result = brain.decide(1, 100, env)
    assert "MOVE" in result
    assert "*" not in result  # Nur Bewegungsbefehl, kein Split


def test_decide_flee_from_stronger(brain):
    """Das Biest soll vor einem stärkeren Gegner fliehen."""
    env = "..>......"
    result = brain.decide(1, 100, env)
    assert "MOVE" in result
    # Soll sich in eine negative Richtung (dx oder dy) bewegen
    parts = result.split()
    dx, dy = int(parts[-2]), int(parts[-1])
    assert dx <= 0 or dy <= 0  # Flucht vom Gegner weg


def test_decide_chase_weaker(brain):
    """Das Biest soll einen schwächeren Gegner jagen."""
    env = "..<......"
    result = brain.decide(1, 100, env)
    assert "MOVE" in result


def test_decide_split_when_enough_energy(brain):
    """Wenn genug Energie vorhanden ist, soll ein Split erfolgen."""
    env = "........."
    result = brain.decide(1, 40000, env)
    assert "SPLIT" in result


def test_decide_move_to_center(brain):
    """Ohne besondere Ereignisse soll das Biest sich zur Spielfeldmitte bewegen."""
    env = "........."
    result = brain.decide(1, 100, env)
    assert "MOVE" in result


def test_decide_stay_when_blocked_by_relative(brain):
    """Wenn Verwandte im Weg stehen, bleibt das Biest stehen."""
    env = "...#....."  # Verwandter direkt vor dem Biest
    result = brain.decide(1, 100, env)
    assert result.endswith("MOVE 0 0")

def test_decide_move_to_center_when_blocked(brain):
    """Wenn Zentrum blockiert ist"""
    env = "....#...."
    result = brain.decide(1, 100, env)
    assert result.endswith("MOVE 0 0")

def test_decide_move_on_combined_cases(brain):
    """Kombination verschiedener Fälle"""
    env = ".*<.#...>"
    result = brain.decide(1, 100, env)
    assert result.endswith("MOVE 0 -1")

def test_decide_move_on_combined_cases_2(brain):
    env = ".>.....<.#.. "
    result = brain.decide(2, 100, env)
    assert result.endswith("MOVE -1 2")