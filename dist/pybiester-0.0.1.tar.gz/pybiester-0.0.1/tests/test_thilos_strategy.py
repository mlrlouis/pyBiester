"""
Tests für thilo_strategy.py
"""
import pytest
from pyBiester.thilos_strategy import (
    BIESTER,
    Symbol,
    WELT_X,
    WELT_Y,
    get_cords,
    get_movement_to_coords,
    get_costs,
    get_cheapest_position,
    is_symbol_in_reachable_enviroment,
    clean_of_not_reachable,
    eat_victim,
    get_best_food,
    get_idle,
    contains_profit,
    clean_of_enemy,
    clean_of_victim_siblings,
    get_action,
    clean_biester,
    print_enviroment,
)


@pytest.fixture(autouse=True)
def reset_biester():
    """Setzt den Biester-Logger vor jedem Test zurück."""
    clean_biester()


# --- Erweiterte Tests für BiesterLogger ---

def test_contains_biest_at_cords_false_initially():
    """Wenn keine Biester vorhanden sind, soll False zurückgegeben werden."""
    assert BIESTER.contains_biest_at_cords((5, 5)) is False


def test_log_and_contains_biest_at_cords_true():
    """Nach dem Hinzufügen eines Biests wird es an der Position gefunden."""
    BIESTER.log_movement(1, (0, 0))
    coords = BIESTER.get_biest_coords(1)
    assert isinstance(coords, tuple)
    assert BIESTER.get_biester()[1] == coords


def test_clean_biester_direct_call():
    """Direkter Test der clean_biester()-Funktion."""
    BIESTER.log_movement(1, (1, 1))
    assert len(BIESTER.get_biester()) > 0
    clean_biester()
    assert not BIESTER.get_biester()


# --- Erweiterte Hilfsfunktionen ---

def test_get_cords_when_no_biester():
    """get_cords sollte auch ohne gespeicherte Biester funktionieren."""
    clean_biester()
    cords = get_cords(0, 99)
    assert isinstance(cords, tuple)
    assert len(cords) == 2


def test_get_costs_when_far_apart():
    """Testet Kostenberechnung bei größeren Distanzen."""
    cost = get_costs((40, 40), 1)
    assert isinstance(cost, int)
    assert cost >= 0


def test_is_symbol_in_reachable_enviroment_no_symbol():
    """Wenn kein Symbol vorhanden ist, soll False zurückkommen."""
    env = "..........."
    result = is_symbol_in_reachable_enviroment(env, Symbol.FOOD, 1, 100)
    assert result is False


def test_clean_of_not_reachable_border_cases():
    """Testet, dass Randsymbole korrekt entfernt werden."""
    env = "*******"
    cleaned = clean_of_not_reachable(env, Symbol.FOOD)
    assert len(cleaned) == len(env)
    assert isinstance(cleaned, str)


# --- print_enviroment ---

def test_print_enviroment_output(capsys):
    """Überprüft, dass print_enviroment formatierte Ausgabe erzeugt."""
    env = "........*........."
    print_enviroment(env)
    out, _ = capsys.readouterr()
    assert "*" in out
    assert "\n" in out


# --- Erweiterte Entscheidungslogik ---

def test_clean_of_enemy_really_removes_food():
    """Food nahe eines Enemies soll wirklich verschwinden."""
    env = "..>.*..*.."
    cleaned = clean_of_enemy(env, 1)
    assert Symbol.FOOD.value not in cleaned[:5]  # nahe Enemy entfernt


def test_get_action_with_enemy_triggers_flee():
    """Wenn ein Enemy im Sichtfeld ist, soll eine Bewegung erfolgen."""
    env = "...>......."
    command, env_out = get_action(env, 1, 100)
    assert "MOVE" in command
    assert not command.endswith("MOVE 0 0")
    assert isinstance(env_out, str)


def test_get_action_with_multiple_symbols():
    """Kombinierter Fall mit Enemy, Food und Victim."""
    env = "..>..<..*."
    command, env_out = get_action(env, 1, 100)
    assert "MOVE" in command
    assert isinstance(env_out, str)


def test_clean_of_victim_siblings_no_biests():
    """Wenn keine Biester gespeichert sind, bleibt das Environment gleich."""
    env = ".....<....."
    cleaned = clean_of_victim_siblings(env, 1)
    assert isinstance(cleaned, str)
    assert len(cleaned) == len(env)

# Bewegungs und Kostenfunktionen

def test_get_movement_to_coords_basic():
    """Bewegung von Start zu Ziel sollte korrekte Differenz liefern."""
    result = get_movement_to_coords((5, 7), (2, 3))
    assert result == (3, 4)


def test_get_cheapest_position_returns_24_if_energy_too_low():
    """Wenn Energie zu niedrig, sollte 24 zurückgegeben werden."""
    env = ".....*....."
    pos = get_cheapest_position(env, Symbol.FOOD, 1, energy=0)
    assert pos == 24


def test_get_cheapest_position_valid_choice():
    """Soll eine gültige Position für vorhandenes Symbol liefern."""
    env = ".....*....."
    pos = get_cheapest_position(env, Symbol.FOOD, 1, energy=100)
    assert isinstance(pos, int)
    assert pos != -1

# Kampf- und Fresslogik

def test_eat_victim_returns_valid_move_string():
    """eat_victim soll korrekten MOVE-Befehl zurückgeben."""
    env = ".....<....."
    cmd = eat_victim(env, 1, 100)
    assert cmd.startswith("1 MOVE")
    assert "MOVE 0 0" not in cmd


def test_get_best_food_returns_valid_move_string():
    """get_best_food soll MOVE-Befehl enthalten."""
    env = ".....*....."
    cmd = get_best_food(env, 1, 100)
    assert "MOVE" in cmd

# Leerlauf und Profitbewertung

def test_get_idle_no_enemy_returns_idle_move():
    """Ohne Enemy sollte Idle-Befehl (MOVE 0 0) zurückkommen."""
    env = "..........."
    cmd = get_idle(env, 1, 100)
    assert cmd.endswith("MOVE 0 0")


def test_get_idle_with_enemy_triggers_food_strategy():
    """Mit Enemy soll get_idle get_best_food aufrufen."""
    env = "...>......."
    cmd = get_idle(env, 1, 100)
    assert "MOVE" in cmd
    assert not cmd.endswith("MOVE 0 0")


def test_contains_profit_true_when_food_close_enough():
    """Soll True liefern, wenn erreichbares Essen vorhanden ist."""
    env = ".....*...."
    assert contains_profit(env, 1, 100) is True


def test_contains_profit_false_when_no_food():
    """Soll False liefern, wenn kein Essen im Sichtfeld."""
    env = "..........."
    assert contains_profit(env, 1, 100) is False

# Randfälle im BiesterLogger

def test_get_biest_coords_with_invalid_id_returns_default():
    """Nicht existierende Biest-ID soll Default-Koordinaten liefern."""
    clean_biester()
    coords = BIESTER.get_biest_coords(999)
    assert coords == (20, 20)


def test_log_movement_wraps_around_world():
    """Bewegung über Weltgrenzen soll korrekt 'umwickeln'."""
    clean_biester()
    BIESTER.log_movement(1, (WELT_X + 1, WELT_Y + 1))
    coords = BIESTER.get_biester()[1]
    assert isinstance(coords, tuple)
    assert all(isinstance(c, int) for c in coords)
